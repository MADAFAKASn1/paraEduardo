package com.example.objetosparcelables;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Contacto contacto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            contacto = new Contacto("Pedro Perez","643534534",2,sdf.parse("21/01/2000"),false);
            contacto.addFamiliar(new Contacto("Belen Perez","342432432",0,sdf.parse("20/05/2000"),false));
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        TextView t = (TextView) findViewById(R.id.textView);
        t.setText("Vamos a enviar los datos de "+contacto.mNombre);
    }

    @Override
    public void onClick(View view) {
        Intent i =  new Intent(this,ActivityB.class);
        i.putExtra("pedro",contacto);
        startActivity(i);
    }
}